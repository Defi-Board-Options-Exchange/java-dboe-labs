C:\Program Files\OpenSSL-Win64\bin\openssl.exe pkcs12 -export -in all_combined.crt -inkey generated-private-key.txt -out keystore.p12 -CAfile temp.crt

"C:\Program Files\OpenSSL-Win64\bin\openssl.exe" pkcs12 -info -in keystore.p12  -noout
"C:\Program Files\Java\jdk1.8.0_331\bin\keytool" -importkeystore -srckeystore keystore.p12 -destkeystore dboeServerCert.jks -srcstoretype pkcs12 -deststoretype jks